<template>
  <section class="page-heading">
    <p class="eyebrow">About</p>
    <h1>关于 gonnabeok</h1>
    <p>一个持续记录工程实践、学习路径和项目复盘的个人技术空间。</p>
  </section>

  <section class="about-layout">
    <div class="about-main">
      <h2>我在关注什么</h2>
      <p>
        这个博客会优先记录前端工程、Vue 生态、部署流程和真实项目中的取舍。目标不是写得很满，而是每篇都能留下一个清楚的问题和答案。
      </p>
      <p>
        后续可以在这里补充你的个人介绍、项目经历、技术栈、联系方式，以及 Gitee、邮箱或社交主页链接。
      </p>
    </div>

    <aside class="about-panel">
      <h2>方向</h2>
      <ul>
        <li>Vue 3 与组件设计</li>
        <li>前端工程化与部署</li>
        <li>技术学习与复盘</li>
      </ul>
    </aside>
  </section>
</template>
