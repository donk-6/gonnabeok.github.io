export const site = {
  // 站点名称，目前用于显示
  name: 'gonnabeok',
  // ============ 头像图片路径填在下面这一行 ============
  // 例：把图片放到 public/ 目录（如 public/avatar.jpg），
  //     然后在这里填 avatar: '/avatar.jpg'
  // 留空（''）时显示字母 G；想用 src/assets/ 里的图片，
  //     改成 import avatar from './assets/avatar.jpg'，avatar: avatar
  avatar: '',
}
